(function(){
    var display = document.getElementById('txtDisplay');
    var expr = "";
    function refreshDisplay() {
        display.value = expr === "" ? "0" : expr.slice(-24);
    }
    function tokenize(s) {
        var tokens = [], i=0;
        while(i<s.length){
            var ch = s[i];
            if(/\d|\./.test(ch)){ var num=ch; i++; while(i<s.length && /[\d.]/.test(s[i])) num+=s[i++]; tokens.push(num); continue; }
            if(/[+\-*/()]/.test(ch)){ tokens.push(ch); i++; continue; }
            i++;
        } return tokens;
    }
    function toRPN(tokens){
        var out=[], ops=[], prec={'+':1,'-':1,'*':2,'/':2};
        for(var i=0;i<tokens.length;i++){
            var t=tokens[i];
            if(/^[\d.]+$/.test(t)){ out.push(t); continue; }
            if(t in prec){
                while(ops.length){ var o2=ops[ops.length-1]; if(o2 in prec && prec[o2]>=prec[t]) out.push(ops.pop()); else break; }
                ops.push(t); continue;
            }
            if(t==='('){ ops.push(t); continue; }
            if(t===')'){ while(ops.length && ops[ops.length-1]!=='(') out.push(ops.pop()); if(ops.length && ops[ops.length-1]==='(') ops.pop(); else throw"Mismatched parentheses"; continue; }
        }
        while(ops.length){ var op=ops.pop(); if(op==='('||op===')') throw"Mismatched parentheses"; out.push(op); }
        return out;
    }
    function evalRPN(rpn){
        var st=[];
        for(var i=0;i<rpn.length;i++){
            var t=rpn[i];
            if(/^[\d.]+$/.test(t)) st.push(parseFloat(t));
            else{ if(st.length<2) throw"Invalid expression"; var b=st.pop(),a=st.pop(),res=0; if(t==='+') res=a+b; else if(t==='-') res=a-b; else if(t==='*') res=a*b; else if(t==='/'){ if(b===0) throw"Division by zero"; res=a/b; } st.push(res); }
        }
        if(st.length!==1) throw"Invalid expression";
        return st[0];
    }
    function evaluateExpression(s){ if(s.trim()==="") return 0; return evalRPN(toRPN(tokenize(s))); }
    function appendInput(ch){ var last=expr.split(/[+\-*/()]/).pop(); if(ch==='.' && last.indexOf('.')!==-1) return; expr+=ch; refreshDisplay(); }
    function appendOperator(op){ if(expr==="" && (op==='+'||op==='-')) expr="0"+op; else{ if(/[+\-*/]$/.test(expr)) expr=expr.slice(0,-1)+op; else expr+=op; } refreshDisplay(); }
    function backspace(){ if(expr.length>0) expr=expr.slice(0,-1); refreshDisplay(); }
    function clearAll(){ expr=""; refreshDisplay(); }
    function equals(){ try{ expr=String(evaluateExpression(expr)); refreshDisplay(); }catch(e){ display.value="Error"; expr=""; } }
    function addBtnHandler(id,fn){ var btn=document.getElementById(id); if(btn) btn.addEventListener('click',fn); }
    refreshDisplay();
    for(var d=0;d<=9;d++) addBtnHandler('btn'+d,(function(c){ return function(){ appendInput(c); };})(String(d)));
    addBtnHandler('btnDot',function(){ appendInput('.'); });
    addBtnHandler('btnPlus',function(){ appendOperator('+'); });
    addBtnHandler('btnMinus',function(){ appendOperator('-'); });
    addBtnHandler('btnMul',function(){ appendOperator('*'); });
    addBtnHandler('btnDiv',function(){ appendOperator('/'); });
    addBtnHandler('btnBack',function(){ backspace(); });
    addBtnHandler('btnClear',function(){ clearAll(); });
    addBtnHandler('btnEqual',function(){ equals(); });
    window.addEventListener('keydown',function(e){ var k=e.key;if(/\d/.test(k)) appendInput(k); else if(k==='.') appendInput('.'); else if(k==='+'||k==='-'||k==='*'||k==='/') appendOperator(k); else if(k==='Enter'||k==='='){ equals(); e.preventDefault(); } else if(k==='Backspace') backspace(); else if(k==='Escape') clearAll(); });
})();
